import testcase from './reciter-testcase.js'

testcase([
  's-1.json',
  's-2.json',
  's-3.json',
  't.json',
  'u.json',
  'v.json',
  'w.json',
  'x.json',
  'y.json',
  'z.json',
]);
