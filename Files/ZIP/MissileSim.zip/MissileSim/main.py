import math, random, noise, turtle, os
import numpy as np
import pandas as pd
from tkinter import *
import matplotlib.pyplot as plt
from PIL import Image, ImageTk
from matplotlib.colors import LinearSegmentedColormap
from turtle import _Root

# GAME SETTINGS
wrldHeight = 100000 # MAX HEIGHT (ALSO CHANGES MOUNTAIN AND VALLEY SIZE)
wrldLen = 100000 # MAX X VALUE (CHANGES THE HORIZONTAL SIZE OF THE WORLD)
wrldIntensity = 4
trtlScreenSize = 300
gameSpeed = 1.0
listOfTargets = [
    ["TOWN", "red"],
    ["MILITARY BASE", "red"],
    ["GROUND ZERO", "red"]
]
currentLanguage = ["English", "Mandarin"][0]
translations = {
                "English": ["Auto Thrust Optimization (Off)", "Auto Thrust Optimization (On)", "Control Panel", "FUEL (%)", "THRUST (%)", "SPEED (MPH)", "MIN SPEED (MPH)", "THRUSTER ROTATION", "ROCKET ROTATION", "ALTITUDE (MILES)", "Start Simulation", "Position", "MIN SPEED", "GAME SPEED", "DISPLAY UNIT", "MISS", "HIT", "Yards"],
                "Mandarin": ["自动推力优化（关闭）", "自动推力优化（开启）", "控制面板", "燃料（%）", "推力（%）", "速度（英里/小时）", "最小速度（英里/小时）", "推进器旋转", "火箭旋转", "高度（英里）", "开始模拟", "位置", '最低速度', "游戏速度", "显示单元", "错过", "打", "码数"]
               }
def findDist(x1, y1, x2, y2):
    # Returns the distance between two points (x1, y1), (x2, y2)
    dist = math.sqrt( (x2 - x1)**2 + (y2 - y1)**2 )
    return dist
def toggleAutoThrustOptimization():
    if btnAuto.cget("text") == translations[currentLanguage][1]:
        btnAuto.config(text=translations[currentLanguage][0], background='red')
    else:
        btnAuto.config(text=translations[currentLanguage][1], background='green')
def clearAllExtraWindows():
    """
    This function clears the turtle window if one is running and closes any PLT charts if any are found.
    It also resets the console
    """
    try:
        turtle.Screen().bye()
        turtle.done()
    except turtle.Terminator:
        pass
    plt.close()
    os.system('cls')
def importTerrain(path):
    terrain_data = pd.read_csv(path)
    terrain = terrain_data['Y']
    terrain = (terrain[::int(len(terrain)/trtlScreenSize)])[:-1]
    newArr = []
    for item in terrain:
        newArr.append(item)
    return newArr
def setupcanvas(self, width, height, cWidth, cHeight):
    self._canvas = Canvas(self, width=cWidth, height=cHeight)
    self._canvas.pack(expand=1, fill="both")
_Root.setupcanvas = setupcanvas
def generatePerlinTerrain(length, max_height=20000, scale=1000000, octaves=10, persistence=1.0, lacunarity=1.0, saveCSV=False):
    base = np.random.randint(0, 100)
    mountain = np.zeros(length)
    print("GENERATING TERRAIN...")
    for i in range(length):
        mountain[i] = (noise.pnoise1(i / scale + base, octaves=octaves, persistence=persistence, lacunarity=lacunarity))
    mountain = (mountain - min(mountain)) / (max(mountain) - min(mountain)) * max_height
    if saveCSV:
        toWrite = "X,Y\n"
        for i in range(len(mountain)):
            toWrite += str(i)+", "+str(int(mountain[i]))+"\n"
        open(f"Terrains/{random.randint(10000,99999)}-TERRAIN.csv","w").write(toWrite)
    return mountain
def rotate_rocket_icon(angle):
    global rocket_canvas, original_rocket_image

    # Rotate and resize the rocket image
    rotated_image = original_rocket_image.rotate(360-angle, expand=True)

    # Convert to Tkinter compatible image
    tk_image = ImageTk.PhotoImage(rotated_image)

    # Clear the canvas and redraw the centered image
    rocket_canvas.delete("all")
    rocket_canvas.create_image(75 // 2, 75 // 2, image=tk_image, anchor='center')
    rocket_canvas.image = tk_image  # Keep a reference
def tkSleep(self, time: float) -> None:
    """
        Emulating `time.sleep(seconds)`
        Created by TheLizzard, inspired by Thingamabobs
        Found on stackoverflow
    """
    self.after(int(time * 1000), self.quit)
    self.mainloop()
Misc.tksleep = tkSleep
def setupFlightTurtleDrawing(terrainData: type([])) -> turtle.Turtle:
    flight = turtle.Turtle()
    flight.penup()
    flight.goto(
        0,
        (float(terrainData[int(trtlScreenSize / 2)] / wrldHeight) * trtlScreenSize) - (trtlScreenSize / wrldIntensity)
    )
    flight.color('red')
    return flight
def setupTerrainTurtleDrawing(terrainTrtl: turtle.Turtle, terrainData: type([])):
    terrainTrtl.speed(0)
    terrainTrtl.penup()
    terrainTrtl.goto(-(trtlScreenSize / 2),
                     ((terrainData[0] / wrldLen) * trtlScreenSize) - (trtlScreenSize / wrldIntensity))
    terrainTrtl.pendown()
    terrainTrtl.color("white")
    targetX = [random.randint(25, int(len(terrainData) / 2) - 25),
                   random.randint(int(len(terrainData) / 2) + 25, int(len(terrainData)) - 25)][random.randint(0, 1)]
    targetY = 0
    for i in (range(len(terrainData))):
        terrainTrtl.goto(i - (trtlScreenSize / 2),
                         ((terrainData[i] / wrldLen) * trtlScreenSize) - (trtlScreenSize / wrldIntensity))
        if i == targetX:
            targetY = ((terrainData[i] / wrldLen) * trtlScreenSize) - (trtlScreenSize / wrldIntensity)
            target = listOfTargets[random.randint(0, len(listOfTargets) - 1)]
            terrainTrtl.color(target[1])
            terrainTrtl.dot(5)
            terrainTrtl.color("white")
            print(f"{target[0]} SPOTTED: X = {targetX - int(len(terrainData) / 2)}")
    terrainTrtl.hideturtle()
    return targetX, targetY
def StartSim():
    # Closes any extra windows when a new simulation is started. Just keeps the screen clean
    clearAllExtraWindows()

    terrain = generatePerlinTerrain(
        length=wrldLen,
        max_height=int(wrldHeight/wrldIntensity),
        scale=int((wrldLen/100000) * 1000 * (wrldIntensity*2.25))
    )

    screen = turtle.Screen()
    screen.setup(width=trtlScreenSize, height=trtlScreenSize, startx=1140)
    screen.screensize(trtlScreenSize, trtlScreenSize)
    screen.setworldcoordinates(-trtlScreenSize/2, -trtlScreenSize/2, trtlScreenSize*.85, trtlScreenSize/2)
    screen.title(translations[currentLanguage][14])
    screen.bgcolor('black')
    screen.tracer(0, 0)

    # DRAW TERRAIN
    terrainData = (terrain[::int(len(terrain)/trtlScreenSize)])[:-1]
    terrainTrtl = turtle.Turtle()
    targetX, targetY = setupTerrainTurtleDrawing(terrainTrtl, terrainData)
    screen.update()

    # DRAW FLIGHT
    flight = setupFlightTurtleDrawing(terrainData)

    btnTh.config(background='red', state="disabled") # Just to stop people from starting a simulation during a simulation
    slRot.config(state="normal") # Making sure that the user can rotate the thruster
    startMass = 50 # Can be changed but 100-50 is a safe bet
    TermVel = -500 # The fastest your rocket can fall (Default: -500)
    slVel.set(0) # Resetting the speedometer
    slTh.set(100) # Setting the thruster speed to 100%, so you don't crash immediately
    fuel = slFuel.cget("from")
    rocketRotation = 180 # 180 is straight up, 90 it left, 270 is right, and 360 or 0 is straight down
    mass = startMass + (fuel / 100) + 0.01
    i = 0 # Simulation Frame
    # ardStream = [[180, 0, 1]] This was output for an arduino board
    position = [0, terrain[int(wrldLen/2)]]
    fuelArr = [fuel]
    xPos = [position[0]]
    yPos = [position[1]]
    """
    Out returns the following data in this exact order
        - x position
        - y position
        - fuel count
        - forward velocity
        - rocket rotation
        - thrust
        - thruster rotation
        - mass
    """
    out = [[position[0], position[1], slFuel.get(), 0, rocketRotation, slVel.get(), 0, (startMass + (fuel / 100))]]
    data = 'X,Y,Fuel,Speed,Rocket Rotation,Thrust,Thruster Rotation,Mass' + '\n'
    data += str((out[-1])).replace('[', '').replace(']', '') + '\n'
    slFuel.set(fuel)
    slRot.set(0)
    while 1:
        i += 1
        slFuel.set(slFuel.get() - (slTh.get()) * (mass / 1500))
        fuel = slFuel.get()
        speed = slVel.get()
        mass = startMass + (fuel / 100) + 0.01
        minSpeed = mass / 2 + 1.75
        if slFuel.get() <= 0:
            slRot.config(state="disabled")
        else:
            slRot.config(state="normal")
        thrusterRotation = slRot.get()
        rocketRotation += (random.randint(-1, 1))
        slRot.set(thrusterRotation)
        if slFuel.get() == 0:
            thrust = 0
            slTh.set(thrust)
            mass = 0
        else:
            thrust = slTh.get()
            if btnAuto.cget("text") == translations[currentLanguage][1]:
                thrust = minSpeed
                slTh.set(minSpeed)
            rocketRotation += ((thrusterRotation * gameSpeed) / 100) * (thrust / 50)
        lblRR.config(text=round(rocketRotation, 2))
        if rocketRotation > 360:
            rocketRotation = 0
        if rocketRotation < 0:
            rocketRotation = 360
        rel = rocketRotation - 180
        speed = speed + ((thrust * 2) - mass) - 3
        lblMin.config(text=f"{translations[currentLanguage][12]}({round(minSpeed, 2)})")
        speed = max(min(speed, slVel.cget("from")), TermVel)

        if i > 10 and thrust == 0:
            if not (fuel == 0 and ((360 - abs(rocketRotation)) < 5 or (abs(rocketRotation)) < 5)):
                if rocketRotation >= 360:
                    rocketRotation = 0
                elif rocketRotation < 0:
                    rocketRotation = 360
                else:
                    if rocketRotation >= 270:
                        rocketRotation += ((360 / (360 - rocketRotation)) * 0.3) + 0.01
                    elif rocketRotation <= 90:
                        rocketRotation -= ((360 / (180 - rocketRotation)) * 0.3) + 0.01
                    else:
                        rocketRotation += ((180 - rocketRotation) * 0.1)
            else:
                rocketRotation = 0
                rotate_rocket_icon(0)
                lblRR.config(text=round(0, 2))
        slVel.set(speed)

        if not (0 > speed and (rocketRotation < 90 or rocketRotation > 270)):
            y = int(position[1] + (math.cos(math.radians(rel)) * (speed * gameSpeed)) * .95)
        else:
            y = int(position[1] + (math.cos(math.radians(rel)) * (-speed * gameSpeed)) * .95)
        x = int(position[0] + (math.sin(math.radians(rel)) * (speed * gameSpeed)))
        trtlX = (float(x / wrldLen) * trtlScreenSize)
        trtlY = (float(y / wrldHeight) * trtlScreenSize) - (trtlScreenSize / wrldIntensity)
        try:
            groundLevel = ((terrainData[int(trtlX + trtlScreenSize/2)] / wrldHeight) * trtlScreenSize) - (trtlScreenSize / wrldIntensity)
        except IndexError:
            groundLevel = ((terrainData[-1] / wrldHeight) * trtlScreenSize) - (trtlScreenSize / wrldIntensity)
        distance = round(findDist(trtlX, groundLevel, targetX - int(len(terrainData) / 2), targetY), 2)
        position = [x, y]
        flight.setheading(-(rocketRotation - 90) + 180)
        root.tksleep(0.01 / slGS.get())
        if  (
                trtlY < groundLevel # Is the rocket above the ground?
                or
                (x >= int(wrldLen / 2) or x <= -int(wrldLen / 2)) # Is the rocket in view of the turtle window?
            )\
                and i >= 100:
            if y <= terrain[int(x)]:
                y = terrain[int(x)]
                xPos.append(x)
                yPos.append(y)
                fuelArr.append(fuel)
                slAlt.set(y - terrain[int(x)])
                data += str((out[-1])).replace('[', '').replace(']', '') + '\n'
                out.append([
                    round(x, 2),
                    round(y, 2),
                    round(fuel),
                    round(speed, 2),
                    round(rocketRotation, 2),
                    round(thrust, 2),
                    round(thrusterRotation, 2),
                    round(mass, 2)
                ])
                rotate_rocket_icon(rocketRotation)

            print("DISTANCE FROM TARGET:", distance)
            slFuel.set(0)
            btnTh.config(background='green', state="normal") # Reset button
            cm = LinearSegmentedColormap.from_list('custom_div_cmap', [(1, 0, 0), (1, 0.5, 0), (0, 1, 0)], N=100) # Initialize color map
            with open(f"Flights_CSV/Flight{random.randint(1000, 9999)}.csv", "w") as fh:
                fh.write(data)

            # Draw flight
            step_size = int(len(xPos)/100)
            if step_size <= 0: step_size=1
            reduced_xPos = [x + (wrldLen / 2) for x in xPos[::step_size]]
            reduced_yPos = yPos[::step_size]
            colors = [cm(fuel / slFuel.cget("from")) for fuel in fuelArr[::step_size]]
            for i, color in enumerate(colors):
                if i < len(reduced_xPos) - 1:
                    plt.plot(reduced_xPos[i:i + 2], reduced_yPos[i:i + 2], color=color, linewidth=3)
            # Draw terrain
            plt.plot(range(0, wrldLen, int(wrldLen / 1000)), terrain[::int(wrldLen / 1000)])

            # Sets the screen color and plot title depending on if you hit close enough to the target
            title, bgColor = (f"{translations[currentLanguage][15]} ({distance} {translations[currentLanguage][17]})", 'red') if distance > 20 else (f"{translations[currentLanguage][16]}! ({distance} {translations[currentLanguage][17]})", 'green')
            screen.bgcolor(bgColor)
            plt.title(title)

            plt.show()
            try:
                turtle.Screen().bye()
                turtle.done()
            except turtle.Terminator:
                pass
            break

        xPos.append(x)
        yPos.append(y)
        fuelArr.append(fuel)
        slAlt.set(y - terrain[int(x)])
        data += str((out[-1])).replace('[', '').replace(']', '') + '\n'
        out.append([
            round(x, 2),
            round(y, 2),
            round(fuel),
            round(speed, 2),
            round(rocketRotation, 2),
            round(thrust, 2),
            round(thrusterRotation, 2),
            round(mass, 2)
        ])
        rotate_rocket_icon(rocketRotation)

        flight.pendown()
        trtlX = (float(x / wrldLen) * trtlScreenSize)
        trtlY = (float(y / wrldHeight) * trtlScreenSize) - (trtlScreenSize / wrldIntensity)
        flight.goto(trtlX, trtlY)
        screen.update()
        flight.penup()

root = Tk()
root.title(translations[currentLanguage][2])
root.resizable(False, True)
window_width = 745
window_height = 360
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
center_x = int(screen_width / 2 - window_width / 2)
center_y = int(screen_height / 2 - window_height / 2)
root.geometry(f'{window_width}x{window_height}+{center_x}+{center_y}')

# Sliders
slFuel = Scale(root, from_=10000, to=0, tickinterval=2500, length=150, bg="grey")
slFuel.grid(column=1, row=2, padx=20)
slTh = Scale(root, from_=100, to=0, tickinterval=25, length=150, bg="grey")
slTh.grid(column=2, row=2)
slVel = Scale(root, from_=150, to=-150, tickinterval=50, length=150, bg="yellow")
slVel.grid(column=3, row=2, padx=20)
slRot = Scale(root, from_=-45, to=45, tickinterval=15, length=275, bg="grey", orient=HORIZONTAL)
slRot.grid(column=2, row=5, pady=10)
slAlt = Scale(root, from_=75000, to=0, tickinterval=10000, length=150, bg="lightblue")
slAlt.grid(column=4, row=2, padx=20)
slGS = Scale(root, from_=0.1, to=2, resolution=0.1, length=150, label=translations[currentLanguage][13], orient=HORIZONTAL)
slGS.grid(column=1, row=5, padx=20)
slGS.set(1)

# Labels
lblFuel = Label(root, text=translations[currentLanguage][3], bg="grey")
lblFuel.grid(column=1, row=1, pady=10)
lblTh = Label(root, text=translations[currentLanguage][4], bg="grey")
lblTh.grid(column=2, row=1, pady=10)
lblVel = Label(root, text=translations[currentLanguage][5], bg="yellow")
lblVel.grid(column=3, row=1, pady=10)
lblMin = Label(root, text=translations[currentLanguage][6], bg="yellow", width=15)
lblMin.grid(column=3, row=3, pady=10, padx=10)
lblTR = Label(root, text=translations[currentLanguage][7], bg="grey")
lblTR.grid(column=2, row=4, pady=10)
lblRR = Label(root, text=translations[currentLanguage][8], bg="grey")
lblRR.grid(column=3, row=4, pady=10)
lblRR = Label(root, text="0", bg="grey", width=6)
lblRR.grid(column=3, row=5, pady=10)
lblAlt = Label(root, text=translations[currentLanguage][9], bg="lightblue")
lblAlt.grid(column=4, row=1, padx=20)

# Buttons
btnTh = Button(root, text=translations[currentLanguage][10], command=StartSim, background='green', state="normal")
btnTh.grid(column=2, row=3)
btnAuto = Button(root, text=translations[currentLanguage][1], command=toggleAutoThrustOptimization, background='green')
btnAuto.grid(column=1, row=3, padx=10)

'''
The following code segment: 
 - Loads the rocket icon
 - Sets the canvas width
 - Creates a canvas
 - Fits it onto the bottem right corner
 - Sets the rocket icon to the default rotation of 180 degrees
'''
original_rocket_image = Image.open('Rocket.png')
canvas_width, canvas_height = 75, 75
rocket_canvas = Canvas(root, width=canvas_width, height=canvas_height)
rocket_canvas.place(relx=1.0, rely=1.0, anchor='se')
rotate_rocket_icon(180)

root.mainloop()