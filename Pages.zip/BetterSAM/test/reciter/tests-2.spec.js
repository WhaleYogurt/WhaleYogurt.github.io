import testcase from './reciter-testcase.js'

testcase([
  'd.json',
  'e.json',
  'f.json',
  'h.json',
  'i.json',
  'j.json',
  'k.json',
  'l.json',
  'm.json',
]);
