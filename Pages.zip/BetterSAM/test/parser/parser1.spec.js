import testcase from './parser1-testcase.js'

testcase([
  'parser1-1.json',
]);
