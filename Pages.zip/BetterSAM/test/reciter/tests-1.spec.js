import testcase from './reciter-testcase.js'

testcase([
  '&.json',
  '\'.json',
  '1.json',
  '2.json',
  '3.json',
  '4.json',
  '5.json',
  '6.json',
  '7.json',
  '8.json',
  '9.json',
  'a.json',
  'b.json',
  'c-1.json',
  'c-2.json',
]);
