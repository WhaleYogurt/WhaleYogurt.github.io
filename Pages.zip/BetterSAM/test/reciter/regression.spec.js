import testcase from './reciter-testcase.js'

testcase(['regression.json']);
