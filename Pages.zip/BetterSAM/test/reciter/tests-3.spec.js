import testcase from './reciter-testcase.js'

testcase([
  'n.json',
  'o.json',
  'p-1.json',
  'p-2.json',
  'q.json',
  'r.json',
  'regression.json',
]);
